#### JuliaMono, a font for programming

JuliaMono is a monospaced typeface designed for programming in text editing environments that require a wide range of specialist and technical Unicode characters. 

![image](https://github.com/cormullion/juliamonomaster/blob/master/images/specimen_1.png)

Visit [https://juliamono.netlify.app](https://juliamono.netlify.app) to find out more.
